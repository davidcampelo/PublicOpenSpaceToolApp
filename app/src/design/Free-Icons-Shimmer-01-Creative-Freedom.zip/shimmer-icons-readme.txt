Shimmer Icons - Free Set

-------------------------------

The 'Shimmer' Icon style is Windows 7 style variant, 20 unique icons are provided free for use in commercial or non-commercial applications, the designs may not be altered in any way and the following attribution must be used, including the link.

<a href="http://www.creativefreedom.co.uk/icon-design/" title="Icon Design by Creative Freedom">Icon Design by Creative Freedom</a>

All copyright for Shimmer Icons belongs to Creative Freedom Ltd.

http://creativecommons.org/licenses/by-nd/3.0/

-------------------------------

Creative Freedom Ltd

http://www.creativefreedom.co.uk/

info@creativefreedom.co.uk

+44 (0)1487 843 493
